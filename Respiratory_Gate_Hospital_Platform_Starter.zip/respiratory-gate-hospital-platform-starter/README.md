# Respiratory Gate Hospital Platform

Starter repository for the Respiratory Gate Egypt hospital Respiratory Care management and financial value platform.

## Start here

Claude Code should read `CLAUDE.md` before making architectural or implementation decisions.

## Source material

- Excel business model: `data/Elite_RT_Value_Calculator.xlsx`
- Brand assets: `brand/`
- Workbook summary: `docs/WORKBOOK_MAP.md`
- Product brief: `docs/PROJECT_BRIEF.md`

## MVP principle

Build the internal operational/financial model first. Do not start with patient-level clinical data or external portals.

## Security

Never commit credentials or patient-identifiable health information to this repository.
